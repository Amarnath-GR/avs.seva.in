
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/whatsapp-webhook.mjs
import { createHmac, createHash, timingSafeEqual } from "node:crypto";
var MAX_BODY_BYTES = 512 * 1024;
var MAX_ENTRIES = 20;
var MAX_CHANGES = 20;
var MAX_MESSAGES = 50;
function pseudonymise(phone) {
  const salt = process.env.WHATSAPP_LOG_SALT;
  if (!salt) {
    console.error(JSON.stringify({ event: "whatsapp_config_error", reason: "log_salt_not_configured" }));
    return "unconfigured";
  }
  return createHash("sha256").update(`${salt}:${String(phone)}`).digest("hex").slice(0, 16);
}
function safeEqual(a, b) {
  const left = Buffer.from(a || "", "utf8");
  const right = Buffer.from(b || "", "utf8");
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}
function signatureIsValid(rawBody, header, appSecret) {
  if (!appSecret) {
    console.error(JSON.stringify({ event: "whatsapp_signature_error", reason: "app_secret_not_configured" }));
    return false;
  }
  if (!header || !header.startsWith("sha256=")) return false;
  const expected = "sha256=" + createHmac("sha256", appSecret).update(rawBody, "utf8").digest("hex");
  return safeEqual(expected, header);
}
var BRIDGE_TIMEOUT_MS = 8e3;
var MAX_REPLY_CHARS = 4096;
var BRIDGE_HOSTS = [
  // A named Cloudflare tunnel, so this address does not change on restart.
  "https://bridge.avsseva.in",
  // The previous quick tunnel, kept only while it still resolves. A quick
  // tunnel's hostname is random and dies with the process, so this is a
  // short-lived fallback rather than a second permanent route.
  "https://exceed-paragraphs-regardless-referrals.trycloudflare.com"
];
function bridgeCandidates() {
  const secret = process.env.AVS_BRIDGE_SECRET;
  if (!secret) return [];
  const configured = process.env.AVS_BRIDGE_URL;
  if (configured) return [{ url: configured, secret }];
  return BRIDGE_HOSTS.map((url) => ({ url, secret }));
}
async function sendWhatsAppText(to, text) {
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneNumberId) {
    console.error(JSON.stringify({ event: "whatsapp_send_skipped", reason: "credentials_missing" }));
    return false;
  }
  const endpoint = `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`;
  const res = await fetch(endpoint, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body: String(text).slice(0, MAX_REPLY_CHARS) }
    })
  });
  if (!res.ok) {
    console.warn(JSON.stringify({ event: "whatsapp_send_failed", status: res.status }));
    return false;
  }
  return true;
}
async function forwardToBridge(payload) {
  const candidates = bridgeCandidates();
  if (candidates.length === 0) {
    console.warn(JSON.stringify({
      event: "whatsapp_bridge_skipped",
      reason: process.env.AVS_BRIDGE_SECRET ? "no_url" : "no_secret"
    }));
    return { handled: 0, replied: 0 };
  }
  let body = null;
  let lastReason = "unknown";
  for (const config of candidates) {
    try {
      const res = await fetch(config.url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Avs-Bridge-Secret": config.secret },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(BRIDGE_TIMEOUT_MS)
      });
      if (!res.ok) {
        lastReason = `status_${res.status}`;
        continue;
      }
      body = await res.json();
      break;
    } catch (err) {
      lastReason = String(err && err.name);
    }
  }
  if (body === null) {
    console.warn(JSON.stringify({ event: "whatsapp_bridge_unreachable", reason: lastReason }));
    return { handled: 0, replied: 0 };
  }
  const messages = [];
  for (const entry of (payload.entry || []).slice(0, MAX_ENTRIES)) {
    for (const change of (entry.changes || []).slice(0, MAX_CHANGES)) {
      for (const m of ((change.value || {}).messages || []).slice(0, MAX_MESSAGES)) {
        messages.push(m);
      }
    }
  }
  let replied = 0;
  const results = body && body.results || [];
  const hasIds = results.some((r) => r && r.id);
  const byId = /* @__PURE__ */ new Map();
  for (const r of results) {
    if (r && r.id) byId.set(r.id, r);
  }
  for (let i = 0; i < messages.length; i += 1) {
    const to = messages[i].from;
    const result = hasIds ? byId.get(messages[i].id) : results[i];
    const reply = result && result.reply;
    if (!to || !reply) continue;
    try {
      if (await sendWhatsAppText(to, reply)) replied += 1;
    } catch (err) {
      console.warn(JSON.stringify({ event: "whatsapp_send_error", reason: String(err && err.name) }));
    }
  }
  return { handled: body && body.handled || messages.length, replied };
}
var whatsapp_webhook_default = async (request) => {
  const expected = process.env.WHATSAPP_VERIFY_TOKEN;
  if (request.method === "GET") {
    const params = new URL(request.url).searchParams;
    if (params.get("hub.mode") === "subscribe" && params.get("hub.verify_token") === expected) {
      return new Response(params.get("hub.challenge") || "", { status: 200 });
    }
    return new Response("verification failed", { status: 403 });
  }
  if (request.method !== "POST") {
    return new Response("method not allowed", { status: 405 });
  }
  let rawBody;
  try {
    rawBody = await request.text();
  } catch {
    return new Response("unreadable body", { status: 400 });
  }
  const signature = request.headers.get("x-hub-signature-256");
  if (rawBody.length > MAX_BODY_BYTES) {
    console.warn(JSON.stringify({
      event: "whatsapp_payload_too_large",
      bytes: rawBody.length
    }));
    return new Response("payload too large", { status: 413 });
  }
  if (!signatureIsValid(rawBody, signature, process.env.WHATSAPP_APP_SECRET)) {
    console.warn(JSON.stringify({ event: "whatsapp_signature_rejected" }));
    return new Response("invalid signature", { status: 401 });
  }
  let payload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return new Response("invalid json", { status: 400 });
  }
  const entries = (payload.entry || []).slice(0, MAX_ENTRIES);
  for (const entry of entries) {
    for (const change of (entry.changes || []).slice(0, MAX_CHANGES)) {
      const value = change.value || {};
      for (const message of (value.messages || []).slice(0, MAX_MESSAGES)) {
        console.log(JSON.stringify({
          event: "whatsapp_message",
          sender: pseudonymise(message.from),
          message_type: message.type,
          timestamp: message.timestamp
        }));
      }
      for (const status of value.statuses || []) {
        console.log(JSON.stringify({
          event: "whatsapp_status",
          id: status.id,
          status: status.status,
          timestamp: status.timestamp
        }));
      }
    }
  }
  const results = await forwardToBridge(payload);
  console.log(JSON.stringify({
    event: "whatsapp_bridge",
    handled: results.handled,
    replied: results.replied
  }));
  return new Response("EVENT_RECEIVED", { status: 200 });
};
export {
  whatsapp_webhook_default as default
};
