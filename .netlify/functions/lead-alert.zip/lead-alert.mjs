
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lead-alert.mjs
var BRIDGE = process.env.AVS_BRIDGE_URL;
var SECRET = process.env.AVS_BRIDGE_SECRET;
var lead_alert_default = async (req) => {
  if (req.method !== "POST") return { statusCode: 405, body: "no" };
  if (!BRIDGE || !SECRET) {
    console.error("lead-alert: bridge not configured");
    return { statusCode: 200, body: "OK" };
  }
  let form = {};
  try {
    form = JSON.parse(req.body || "{}");
  } catch {
    form = {};
  }
  const name = String(form.name || "").slice(0, 100);
  const email = String(form.email || "").slice(0, 200);
  const message = String(form.message || "").slice(0, 2e3);
  try {
    const res = await fetch(`${BRIDGE}/lead`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Avs-Bridge-Secret": SECRET },
      body: JSON.stringify({ name, email, message })
    });
    if (!res.ok) console.error("lead-alert: bridge refused", res.status);
  } catch (e) {
    console.error("lead-alert: unreachable", e.message);
  }
  return { statusCode: 200, body: "OK" };
};
export {
  lead_alert_default as default
};
